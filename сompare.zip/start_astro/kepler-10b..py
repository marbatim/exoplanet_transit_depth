#COMPARE TRANSITS (Kepler-90h & Kepler-10b)

import lightkurve as lk
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

search_exo = lk.search_lightcurve('Kepler-10b', quarter=5)
lc = search_exo.download()
clean_lc = lc.remove_nans().flatten()

plt.figure(figsize=(10, 5))
clean_lc.scatter()
plt.title('Exploring the Kepler-10b planet')

plt.xlim(452, 457) #slices with xlim

plt.show()